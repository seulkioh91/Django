from django.urls import path

from . import views # .(dot) mean is get the same directory's views

urlpatterns = [
    path('', views.index, name='index'), #call 'index' in the views
    path('<int:question_id>/', views.detail, name='dateil'),
    path('<int:question_id>/results/', views.results, name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),
]